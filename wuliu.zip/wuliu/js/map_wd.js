layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	//引入layui
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer
		$(function() {
			var map = new AMap.Map('mapcontainer', {
				resizeEnable: true,
				zoom: 12,
			});
			AMap.plugin(['AMap.ToolBar', 'AMap.Scale', 'AMap.OverView'], function() {
				map.addControl(new AMap.ToolBar());
				map.addControl(new AMap.Scale());
			});
			//输入关键词位置定位
			var auto = new AMap.Autocomplete({
				input: "positionsearch"
			});
			AMap.event.addListener(auto, 'select', function(e) {
				map.setCenter(e.poi.location)
			});
			var marker = createMarker();
			AMap.event.addListener(marker,'click',function(e){
				vehiclepop(1);
			});
		    function createMarker(data) {
				var lnglat = [];
				lnglat[0] = 117;
				lnglat[1] = 39.08;
				var marker = new AMap.Marker({
					draggable: false,
					cursor: "move",
					position: lnglat,
					label: { content: '津A111', offset: new AMap.Pixel(-20, 25) }
				});
				marker.setMap(map);
				return marker;
			}
// 
//		    _onClick = function(e) {
//				
//			}
		});
	$(document).on('click','#myPageTop i',function(){
		$('#myPageTop').hide();
	})
		
})