layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
		form = layui.form;

	table.render({
		elem: '#statisticDateReportTable',
		height: '471',
		limit: 10,
		page: true,
		id: 'testReload',
		cols: [
			[ //表头
				{
					type: 'numbers'
				},
				{
					field: 'num',
					title: '车牌号',
					//width: 100,
					sort: true,
				}, {
					field: 'color',
					title: '车辆颜色',
					//width: 100,
					sort: true,
				}, {
					field: 'date',
					title: '日期',
					//width: 110,
					sort: true
				}, {
					field: 'datenum',
					title: '数据上报条数',
					//width: 140,
					sort: true
				},
			]
		],
		data: [{
			num: "津ABC23",
			color: "红色",
			date: "2019-09-12",
			datenum: "10"
		}, {
			num: "津ABC23",
			color: "红色",
			date: "2019-09-12",
			datenum: "10"
		}, {
			num: "津ABC23",
			color: "红色",
			date: "2019-09-12",
			datenum: "10"
		}, {
			num: "津ABC23",
			color: "红色",
			date: "2019-09-12",
			datenum: "10"
		}, ]
	});

	var $ = layui.$,
		active = {
			reload: function() {
				var demoReload = $('#demoReload');

				//执行重载
				table.reload('testReload', {
					page: {
						curr: 1 //重新从第 1 页开始
					},
					where: {
						key: {
							id: demoReload.val()
						}
					}
				});
			}
		};

	$('.demoTable .layui-btn').on('click', function() {
		var type = $(this).data('type');
		active[type] ? active[type].call(this) : '';

	});

	$(function() {
		//引入引入左边栏树状图
		var form = layui.form;
		var data = [{
			title: "全部",
			value: "all",
			data: [{
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}]
		}]
		//测试用，以循环形式产生树状图内容
		for(var one in data[0].data) {
			for(var i = 0; i < 20; i++) {
				data[0].data[one].data.push({
					title: "节点111",
					checked: true,
					disabled: false,
					value: "jd1.1",
					data: []
				})
			}
		}
		//生成树状图
		var sidertree = new layuiXtree({
			elem: 'statisticDateReport-xtree',
			form: form,
			color: {
				open: "#EE9A00",
				close: "#EEC591",
				end: "#c8c8c8"
			},
			data: data,

			click: function(data) {}
		})
	})
});

layui.use(['form', 'layedit', 'laydate'], function() {
	var form = layui.form,
		layer = layui.layer,
		layedit = layui.layedit,
		laydate = layui.laydate;

	//日期
	laydate.render({
		elem: '#statisticDateReportEnddate'
	});
	laydate.render({
		elem: '#statisticDateReportStartdate'
	});

});