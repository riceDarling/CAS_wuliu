
			layui.use(['jquery', 'element', 'form', 'table', 'layer', 'laydate'], function() {
				var element = layui.element,
					$ = layui.$,
					layer = layui.layer,
					table = layui.table;
					table.render({
						elem: '#cusAPPTable',
						height: '471',
						limit: 10,
						page: true,
						cols: [
							[ //表头
								{
									field: 'title',
									title: '标题',
									width: 100,
									sort: true,
								}, {
									field: 'image',
									title: '缩略图',
									width: 100,
									sort: true,
								}, {
									field: 'figure',
									title: '轮播图',
									width: 100,
									sort: true
								}, {
									field: 'isfigure',
									title: '是否为轮播',
									width: 110,
									templet: '#cusAPPcheckboxTpl',
									unresize: false,
								},{
									field: 'time',
									title: '创建时间',
									width: 180,
									sort: true,
								},{
									field: 'operation',
									title: '具体操作',
									width: 180,
									sort: true,
									toolbar: '#cusAppbar',
								}]
						],
						data: [{
							id: 1,
							title: "物流近况",
							image: "admin",
							figure: "面板信息",
							isfigure: true,
							time:"2018-10-01 10:00:00",
							
						}, {
							id: 1,
							title: "物流近况",
							image: "admin",
							figure: "面板信息",
							isfigure: true,
							time:"2018-10-01 10:00:00",
						}, {
							id: 1,
							title: "物流近况",
							image: "admin",
							figure: "面板信息",
							isfigure: true,
							time:"2018-10-01 10:00:00",
						}, {
							id: 1,
							title: "物流近况",
							image: "admin",
							figure: "面板信息",
							isfigure: true,
							time:"2018-10-01 10:00:00",
						}, 
						{
							id: 1,
							title: "物流近况",
							image: "admin",
							figure: "面板信息",
							isfigure: true,
							time:"2018-10-01 10:00:00",
						}, {
							id: 1,
							title: "物流近况",
							image: "admin",
							figure: "面板信息",
							isfigure: true,
							time:"2018-10-01 10:00:00",
						}]
					});
					table.on('tool(cusAPPTable)', function(obj) {
						var data = obj.data;
						if(obj.event === 'detail') {
								editpop("newsDetail.html?"+data.id);
						} else if(obj.event === 'del') {
							layer.confirm('真的删除行么', function(index) {
								obj.del();
								layer.close(index);
							});
						} else if(obj.event === 'edit') {
							editpop("newsEdit.html?"+data.id);
//							layer.alert('编辑行：<br>' + JSON.stringify(data))
						}
					});
				});
				