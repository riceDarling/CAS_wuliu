layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	form = layui.form;

	//监听工具条
	table.on('tool(demo)', function(obj) {
		var data = obj.data;

		if(obj.event === 'detail') {
			editpop("transportVehicleDetail.html?" + data.id);
		} else if(obj.event === 'del') {
			layer.confirm('真的删除行么', function(index) {
				obj.del();
				layer.close(index);
			});
		} else if(obj.event === 'edit') {
			editpop("transportVehicleEdit.html?" + data.id);
		}
	});

	table.render({
		elem: '#vehicleTable',
		height: '471',
		limit: 10,
		page: true,
		id: 'testReload',
		cols: [
			[ //表头
				{
					checkbox: true,
					fixed: true
				}, {
					field: 'id',
					title: 'ID',
					width: 40,
					sort: true,
				}, {
					field: 'num',
					title: '车牌号',
					width: 60,
					sort: true,
				}, {
					field: 'nickname',
					title: '编号',
					width: 80,
					sort: true
				}, {
					field: 'desc',
					title: '车辆类型',
					width: 100,
					sort: true
				}, {
					field: 'cName',
					title: '所属企业',
					width: 100,
					sort: true
				}, {
					field: 'tName',
					title: '车队信息',
					//width: 100,
					sort: true
				}, {
					field: 'state',
					title: '最新状态信息',
					width: 120,
					sort: true
				}, {
					field: 'qrcode',
					title: '二维码',
					width: 90,
					sort: true,
					templet: '#vehiclecodeTpl',
				}, {
					field: 'effective',
					title: '是否冻结',
					width: 110,
					templet: '#vehiclecheckboxTpl',
					unresize: false

				}, {
					field: 'operation',
					title: '具体操作',
					width: 150,
					sort: true,
					toolbar: '#vehiclebar',

				}
			]
		],
		data: [{
				id: 1,
				num: "123",
				nickname: "12344333",
				desc: "1",
				cName: "123",
				tName: "wert",
				state: "123",
				qrcode: "1111",
				effective: true,
			}, {
				id: 2,
				num: "123",
				nickname: "12344333",
				desc: "1",
				cName: "123",
				tName: "wert",
				state: "123",
				qrcode: "1111",
				effective: true,
			}, {
				id: 3,
				num: "123",
				nickname: "12344333",
				desc: "1",
				cName: "123",
				tName: "wert",
				state: "123",
				qrcode: "1111",
				effective: true,
			}, {
				id: 4,
				num: "123",
				nickname: "12344333",
				desc: "1",
				cName: "123",
				tName: "wert",
				state: "123",
				qrcode: "1111",
				effective: true,
			}, {
				id: 5,
				num: "123",
				nickname: "12344333",
				desc: "2",
				cName: "123",
				tName: "wert",
				state: "123",
				qrcode: "1111",
				effective: true,
			}, {
				id: 6,
				num: "123",
				nickname: "12344333",
				desc: "2",
				cName: "123",
				tName: "wert",
				state: "123",
				qrcode: "1111",
				effective: true,
			}, {
				id: 7,
				num: "123",
				nickname: "12344333",
				desc: "2",
				cName: "123",
				tName: "wert",
				state: "123",
				qrcode: "1111",
				effective: true,
			},
			{
				id: 8,
				num: "123",
				nickname: "12344333",
				desc: "2",
				cName: "123",
				tName: "wert",
				state: "123",
				qrcode: "1111",
				effective: true,
			},
		]

	});

	var $ = layui.$,
		active = {
			reload: function() {
				var demoReload = $('#demoReload');

				//执行重载
				table.reload('testReload', {
					page: {
						curr: 1 //重新从第 1 页开始
					},
					where: {
						key: {
							id: demoReload.val()
						}
					}
				});
			}
		};
	
	$('.demoTable .layui-btn').on('click', function() {
		var type = $(this).data('type');
		active[type] ? active[type].call(this) : '';

	});

	//监听锁定操作
	form.on('checkbox(lockDemo)', function(obj) {
		layer.tips(this.value + ' ' + this.name + '：' + obj.elem.checked, obj.othis);
	});
});