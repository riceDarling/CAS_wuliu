layui.use(['jquery', 'element', 'form', 'layedit', 'laydate', 'table', 'layer'], function() {
	var element = layui.element,
		form = layui.form,
		layer = layui.layer,
		laydate = layui.laydate;
	     $ = layui.$,
		layedit = layui.layedit,
		table = layui.table;
	//监听工具条
	table.render({
		elem: '#assigntable',
		height: '471',
		limit: 10,
		page: true,
		cols: [
			[{
				checkbox: true,
				fixed: true
			}, {
				field: 'id',
				title: '司机编号',
				width: 110
			}, {
				field:'name',
				title:'司机姓名',
				width:110
			},{
				field: 'carNum',
				title: '车牌号',
				width: 110
			}, {
				field: 'carSpace',
				title: '车辆剩余空间',
				width: 140
			}, {
				field: 'carArea',
				title: '车辆位置',
				width: 110
			}, {
				title: '具体操作',
				toolbar: '#vehiclecheckboxTpl',
				width: 165
			}]
		],
		id: 'testReload',

		data: [{
			"id": "10001",
			"name": "张三",
			"carNum": "津ANH777",
			"carSpace": "天津",
			"carArea": "38.99002",
		}, {
			"id": "10001",
			"name": "张三",
			"carNum": "津ANH777",
			"carSpace": "天津",
			"carArea": "38.99002",
		}, {
			"id": "10001",
			"name": "张三",
			"carNum": "津ANH777",
			"carSpace": "天津",
			"carArea": "38.99002",
		}, {
			"id": "10001",
			"name": "张三",
			"carNum": "津ANH777",
			"carSpace": "天津",
			"carArea": "38.99002",
		}]
	});
	var $ = layui.$,
		active = {
			reload: function() {
				var demoReload = $('#demoReload');

				//执行重载
				table.reload('testReload', {
					page: {
						curr: 1 //重新从第 1 页开始
					},
					where: {
						key: {
							id: demoReload.val()
						}
					}
				});
			}
		};

	$('.demoTable .layui-btn').on('click', function() {
		var type = $(this).data('type');
		active[type] ? active[type].call(this) : '';

	});
	form.on('checkbox(lockDemo)', function(obj) {
		layer.tips(this.value + ' ' + this.name + '：' + obj.elem.checked, obj.othis);
	});
});