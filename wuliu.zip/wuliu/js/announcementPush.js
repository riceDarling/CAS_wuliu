layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	//引入layui
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
		
	$(function() {

		//引入引入左边栏树状图
		var form = layui.form;
		var data = [{
			title: "全部",
			value: "all",
			data: [{
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}]
		}]
		//测试用，以循环形式产生树状图内容
		for(var one in data[0].data) {
			for(var i = 0; i < 5; i++) {
				data[0].data[one].data.push({
					title: "节点111",
					checked: true,
					disabled: false,
					value: "jd1.1",
					data: []
				})
			}
		}
		//生成树状图
		var sidertree = new layuiXtree({
			elem: 'xtree1',
			form: form,
			color: {
				open: "#EE9A00",
				close: "#EEC591",
				end: "#c8c8c8"
			},
			data: data,
			click: function(data) {
			}
		})
		
	})
    
})

