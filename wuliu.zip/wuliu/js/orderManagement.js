layui.use(['jquery', 'element', 'form', 'layedit', 'laydate', 'table', 'layer'], function() {
	var element = layui.element,
		form = layui.form,
		layer = layui.layer,
		laydate = layui.laydate;
	     $ = layui.$,
		layedit = layui.layedit,
		table = layui.table;
	//监听工具条
	table.on('tool(demo)', function(obj) {
		var data = obj.data;
		if(obj.event === 'detail') {
			editpop("orderManagementDetail.html?"+data.id);
		} else if(obj.event === 'edit') {
			editpop("orderManagementEdit.html?"+data.id);
		}
	});
	table.render({
		elem: '#orderManagementtable',
		height: '471',
		limit: 10,
		page: true,
		cols: [
			[{
				checkbox: true,
				fixed: true
			}, {
				type: 'numbers'
			}, {
				field: 'id',
				title: '订单编号',
				width: 100
			}, {
				field: 'pickupTime',
				title: '取货时间',
				width: 120
			}, {
				field: 'pickupArea',
				title: '取货地址',
				width: 100
			}, {
				field: 'sendArea',
				title: '送货地址',
				width: 100
			}, {
				field: 'pickupCar',
				title: '取货车辆',
				width: 100
			}, {
				field: 'orderStatus',
				title: '订单状态',
				width: 100
			}, {
				title: '具体操作',
				toolbar: '#orderManagementbar',
				width: 200
			}]
		],
		id: 'testReload',

		data: [{
			"id": "10001",
			"pickupTime": "20180131",
			"pickupArea": "跑马地",
			"sendArea": "天津",
			"pickupCar": "斯太尔",
			"orderStatus": "待分配",
		}, {
			"id": "10001",
			"pickupTime": "杜甫",
			"pickupArea": "买买买",
			"sendArea": "13786534567",
			"pickupCar": "11111111111111111",
			"orderStatus": "待分配",
		}, {
			"id": "10001",
			"pickupTime": "杜甫",
			"pickupArea": "买买买",
			"sendArea": "13786534567",
			"pickupCar": "11111111111111111",
			"orderStatus": "待分配",
		}, {
			"id": "10001",
			"pickupTime": "杜甫",
			"pickupArea": "买买买",
			"sendArea": "13786534567",
			"pickupCar": "11111111111111111",
			"orderStatus": "待分配",
		}]
	});
	var $ = layui.$,
		active = {
			reload: function() {
				var demoReload = $('#demoReload');

				//执行重载
				table.reload('testReload', {
					page: {
						curr: 1 //重新从第 1 页开始
					},
					where: {
						key: {
							id: demoReload.val()
						}
					}
				});
			}
		};

	$('.demoTable .layui-btn').on('click', function() {
		var type = $(this).data('type');
		active[type] ? active[type].call(this) : '';

	});
	form.on('checkbox(lockDemo)', function(obj) {
		layer.tips(this.value + ' ' + this.name + '：' + obj.elem.checked, obj.othis);
	});
});