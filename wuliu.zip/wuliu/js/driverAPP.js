layui.use(['jquery', 'element', 'form', 'table', 'layer', 'laydate'], function() {
				var element = layui.element,
					$ = layui.$,
					layer = layui.layer,
					table = layui.table;
				table.render({
					elem: '#driAPPTable',
					height: '471',
					limit: 10,
					page: true,
					cellMinWidth:80,
					cols: [
						[ //表头
							{
								field: 'title',
								title: '标题',
								width:100,
								sort: true,
							}, {
								field: 'image',
								title: '缩略图',
								width:100,
								sort: true,
							}, {
								field: 'figure',
								title: '轮播图',
								width:100,
								sort: true
							}, {
								field: 'isfigure',
								title: '是否为轮播',
								templet: '#driAPPcheckboxTpl',
								width:120,
								unresize: false,
							},{
								field: 'time',
								title: '创建时间',
								width:150,
								sort: true,
							},{
								field: 'operation',
								title: '具体操作',
								sort: true,
								width:180,
								toolbar: '#driAPPbar',
							}]
					],
					data: [{
						id: 1,
						title: "物流近况",
						image: "admin",
						figure: "面板信息",
						isfigure: true,
						time:"2018-10-01 10:00:00",
						
					}, {
						id: 1,
						title: "物流近况",
						image: "admin",
						figure: "面板信息",
						isfigure: true,
						time:"2018-10-01 10:00:00",
					}, {
						id: 1,
						title: "物流近况",
						image: "admin",
						figure: "面板信息",
						isfigure: true,
						time:"2018-10-01 10:00:00",
					}, {
						id: 1,
						title: "物流近况",
						image: "admin",
						figure: "面板信息",
						isfigure: true,
						time:"2018-10-01 10:00:00",
					}, 
					{
						id: 1,
						title: "物流近况",
						image: "admin",
						figure: "面板信息",
						isfigure: true,
						time:"2018-10-01 10:00:00",
					}, {
						id: 1,
						title: "物流近况",
						image: "admin",
						figure: "面板信息",
						isfigure: true,
						time:"2018-10-01 10:00:00",
					}],done:function(){
						
					}
				});
				table.on('tool(driAPPTable)', function(obj) {
						var data = obj.data;
						if(obj.event === 'detail') {
								editpop("newsDetail.html?"+data.id);
						} else if(obj.event === 'del') {
							layer.confirm('真的删除行么', function(index) {
								obj.del();
								layer.close(index);
							});
						} else if(obj.event === 'edit') {
							editpop("newsEdit.html?"+data.id);
//							layer.alert('编辑行：<br>' + JSON.stringify(data))
						}
					});
			});