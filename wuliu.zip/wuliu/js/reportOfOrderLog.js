layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	form = layui.form;
	//监听工具条
	table.on('tool(demo)', function(obj) {
		var data = obj.data;
		if(obj.event === 'detail') {
			layer.msg('ID：' + data.id + ' 的查看操作');
		} 
	});
	table.render({
		elem: '#orderLogTable',
		height: '471',
		limit: 10,
		page: true,
		id: 'testReload',
		cols: [
			[ //表头
				{type:'numbers'},
				{
					field: 'num',
					title: '车牌号',
					//width: 100,
					sort: true,
				}, {
					field: 'color',
					title: '车辆颜色',
					//width: 100,
					sort: true,
				}, {
					field: 'content',
					title: '命令内容',
					//width: 100,
					sort: true
				}, {
					field: 'sendTime',
					title: '发送时间',
					//width: 100,
					sort: true
				}, {
					field: 'status',
					title: '命令回执',
					//width: 100,
					sort: true
				},
			]
		],
		data: [{
			num: "津ABC23",
			color: "蓝",
			content: "12344333",
			sendTime: "2018-01-23",
			status: "成功",
		}, {
			num: "津ABC23",
			color: "蓝",
			content: "12344333",
			sendTime: "2018-01-23",
			status: "成功",
		}, {
			num: "津ABC23",
			color: "蓝",
			content: "12344333",
			sendTime: "2018-01-23",
			status: "成功",
		}, {
			num: "津ABC23",
			color: "蓝",
			content: "12344333",
			sendTime: "2018-01-23",
			status: "成功",
		}, {
			num: "津ABC23",
			color: "蓝",
			content: "12344333",
			sendTime: "2018-01-23",
			status: "成功",
		}, {
			num: "津ABC23",
			color: "蓝",
			content: "12344333",
			sendTime: "2018-01-23",
			status: "成功",
		}, {
			num: "津ABC23",
			color: "蓝",
			content: "12344333",
			sendTime: "2018-01-23",
			status: "成功",
		}, ]
	});
	
	var $ = layui.$, active = {
    reload: function(){
      var demoReload = $('#demoReload');
      
      //执行重载
      table.reload('testReload', {
        page: {
          curr: 1 //重新从第 1 页开始
        }
        ,where: {
          key: {
            id: demoReload.val()
          }
        }
      });
    }
  };
  
  $('.demoTable .layui-btn').on('click', function(){
    var type = $(this).data('type');
    active[type] ? active[type].call(this) : '';
    
  });
	
	
	
	
	$(function() {
		//引入引入左边栏树状图
		var form = layui.form;
		var data = [{
			title: "全部",
			value: "all",
			data: [{
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}]
		}]
		//测试用，以循环形式产生树状图内容
		for(var one in data[0].data) {
			for(var i = 0; i < 20; i++) {
				data[0].data[one].data.push({
					title: "节点111",
					checked: true,
					disabled: false,
					value: "jd1.1",
					data: []
				})
			}
		}
		//生成树状图
		var sidertree = new layuiXtree({
			elem: 'orderLog-xtree',
			form: form,
			color: {
				open: "#EE9A00",
				close: "#EEC591",
				end: "#c8c8c8"
			},
			data: data,
			
			click: function(data) {
			}
		})
	})
});

layui.use(['form', 'layedit', 'laydate'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
  
  //日期
  laydate.render({
    elem: '#orderLogEnddate'
  });
  laydate.render({
    elem: '#orderLogStartdate'
  });
  
  });