layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	form = layui.form;
	//监听工具条
	table.on('tool(demo)', function(obj) {
		var data = obj.data;
		if(obj.event === 'detail') {
			//layer.msg('ID：' + data.id + ' 的查看操作');
			editpop("transportCustomerDetail.html?"+data.id);
		} else if(obj.event === 'del') {
			layer.confirm('真的删除行么', function(index) {
				obj.del();
				layer.close(index);
			});
		} else if(obj.event === 'edit') {
			//layer.alert('编辑行：<br>' + JSON.stringify(data))
			editpop("transportCustomerEdit.html?"+data.id);
		}
	});
	table.render({
		elem: '#customerTable',
		height: '471',
		limit: 10,
		page: true,
		id: 'testReload',
		cols: [
			[ //表头
				{type:'numbers'},
				{
					field: 'id',
					title: '客户编号',
					width: 100,
					sort: true,
				}, {
					field: 'cname',
					title: '客户名称',
					width: 100,
					sort: true,
				}, {
					field: 'ctypename',
					title: '客户类型',
					width: 100,
					sort: true
				}, {
					field: 'contactname',
					title: '联系人',
					width: 80,
					sort: true
				},{
					field: 'tel',
					title: '联系电话',
					width: 100,
					sort: true
				},{
					field: 'addr',
					title: '地址',
					width: 80,
					sort: true
				},
				{
					field: 'operation',
					title: '具体操作',
					//width: 170,
					sort: true,
					toolbar: '#customerbar',

				}
			]
		],
		data: [{
			id: 1,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
		
		}, {
			id: 2,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
		
		}, {
			id: 3,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
		
		}, {
			id: 4,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
		
		}, {
			id: 5,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
		
		}, {
			id: 6,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
	
		}, {
			id: 7,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
			
		}, {
			id: 8,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
			
		}, {
			id: 9,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
			
		}, {
			id: 10,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
			
		}, {
			id: 11,
			cname: "津ABT123",
			ctypename: "12344333",
			contactname: "危险品",
			tel:"123",
			addr:"wert",
			
		}, ]
	});
	
	var $ = layui.$, active = {
    reload: function(){
      var demoReload = $('#demoReload');
      
      //执行重载
      table.reload('testReload', {
        page: {
          curr: 1 //重新从第 1 页开始
        }
        ,where: {
          key: {
            id: demoReload.val()
          }
        }
      });
    }
  };
  
  $('.demoTable .layui-btn').on('click', function(){
    var type = $(this).data('type');
    active[type] ? active[type].call(this) : '';
    
  });
	
	//监听锁定操作
	form.on('checkbox(lockDemo)', function(obj) {
		layer.tips(this.value + ' ' + this.name + '：' + obj.elem.checked, obj.othis);
	});
});