layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	form = layui.form;
	//监听工具条
	table.on('tool(demo)', function(obj) {
		var data = obj.data;
		if(obj.event === 'detail') {
			editpop("transportEnterpriseDetail.html?"+data.id);
		} else if(obj.event === 'edit') {
			editpop("transportEnterpriseEdit.html?"+data.id);
		}
	});
	table.render({
		elem: '#enterprisetable',
		height: '471',
		limit: 10,
		page: true,
		cols: [
			[{
				checkbox: true,
				fixed: true
			}, {
				type: 'numbers'
			}, {
				field: 'id',
				title: '企业编号',
				width: 100

			}, {
				field: 'cName',
				title: '企业名称',
				width: 100
			}, {
				field: 'contact',
				title: '联系人',
				width: 100
			}, {
				field: 'tel',
				title: '联系电话',
				width: 120
			}, {
				field: 'cNum',
				title: '营业执照号',
				width: 120
			}, {
				field: 'createTime',
				title: '加入时间',
				width: 120
			}, {
				field: 'effective',
				title: '是否冻结',
				width: 110,
				templet: '#enterprisecheckboxTpl',
				unresize: false

			}, {
				title: '具体操作',
				toolbar: '#enterprisebar',
				width: 150
			}]
		],
		id: 'testReload',

		data: [{
			"id": "10001",
			"cName": "杜甫",
			"contact": "买买买",
			"tel": "13786534567",
			"cNum": "11111111111111111",
			"createTime": "2020-02-20",
		}, {
			"id": "10001",
			"cName": "杜甫",
			"contact": "男",
			"tel": "浙江杭州",
			"cNum": "人生恰似一场修行",
			"createTime": "2020-02-20",
		}, {
			"id": "10001",
			"cName": "杜甫",
			"contact": "男",
			"tel": "浙江杭州",
			"cNum": "人生恰似一场修行",
			"createTime": "2020-02-20",
		}, {
			"id": "10001",
			"cName": "杜甫",
			"contact": "男",
			"tel": "浙江杭州",
			"cNum": "人生恰似一场修行",
			"createTime": "2020-02-20",
		}]
	});
	var $ = layui.$,
		active = {
			reload: function() {
				var demoReload = $('#demoReload');

				//执行重载
				table.reload('testReload', {
					page: {
						curr: 1 //重新从第 1 页开始
					},
					where: {
						key: {
							id: demoReload.val()
						}
					}
				});
			}
		};

	$('.demoTable .layui-btn').on('click', function() {
		var type = $(this).data('type');
		active[type] ? active[type].call(this) : '';

	});
	form.on('checkbox(lockDemo)', function(obj) {
		layer.tips(this.value + ' ' + this.name + '：' + obj.elem.checked, obj.othis);
	});
});