layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	form = layui.form;
	//监听工具条
	table.on('tool(adminTable)', function(obj) {
		var data = obj.data;
		if(obj.event === 'detail') {
			editpop("adminDetail.html?"+data.id);
		} else if(obj.event === 'del') {
			layer.confirm('真的删除行么', function(index) {
				obj.del();
				layer.close(index);
			});
		} else if(obj.event === 'edit') {
			pop("adminEdit.html?"+data.id);
		}
	});
	table.render({
		elem: '#adminTable',
		height: '471',
		limit: 10,
		page: true,
		cols: [
			[ //表头
				{
					field: 'adminName',
					title: '登录名',
					//						width: 80,
					sort: true,
				}, {
					field: 'lastTime',
					title: '上次登录时间',
					//						width: 80，
					sort: true,
				}, {
					field: 'type',
					title: '管理员类型',
					//						width: 80,
					sort: true
				}, {
					field: 'effective',
					title: '是否锁定',
					width: 110,
					templet: '#admincheckboxTpl',
					unresize: false

				},
				{
					field: 'operation',
					title: '具体操作',
					//						width: 177，
					sort: true,
					toolbar: '#adminbar',

				}
			]
		],
		data: [{
			id: 1,
			adminName: "<script>"+alert('11')+"</script>",
			lastTime: "12344333",
			type: "危险品",
			effective: true,
		}, {
			id: 2,
			adminName: "津ABT123",
			lastTime: "12344333",
			type: "危险品",
			effective: false,
		}, {
			id: 3,
			adminName: "津ABT123",
			lastTime: "12344333",
			type: "危险品",
			effective: true,
		}, {
			id: 4,
			adminName: "津ABT123",
			lastTime: "12344333",
			type: "危险品",
			effective: true,
		}, {
			id: 5,
			adminName: "津ABT123",
			lastTime: "12344333",
			type: "危险品",
			effective: false,
		}, {
			id: 6,
			adminName: "津ABT123",
			lastTime: "12344333",
			type: "危险品",
			effective: true,
		}, {
			id: 7,
			adminName: "津ABT123",
			lastTime: "12344333",
			type: "危险品",
			effective: false,
		}, {
			id: 8,
			adminName: "津ABT123",
			lastTime: "12344333",
			type: "危险品",
			effective: true,
		}, {
			id: 9,
			adminName: "津ABT123",
			lastTime: "12344333",
			type: "危险品",
			effective: false,
		}, {
			id: 10,
			adminName: "津ABT123",
			lastTime: "12344333",
			type: "危险品",
			effective: true,
		}, {
			id: 11,
			adminName: "津ABT123",
			lastTime: "12344333",
			type: "危险品",
			effective: false,
		}, ]
	});
	//监听锁定操作
	form.on('checkbox(lockDemo)', function(obj) {
		layer.tips(this.value + ' ' + this.name + '：' + obj.elem.checked, obj.othis);
	});
});