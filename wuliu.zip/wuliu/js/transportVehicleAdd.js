layui.use('upload', function() {
	var $ = layui.jquery,
		upload = layui.upload;

	//拖拽上传
	upload.render({
		elem: '#uploadImage1,#uploadImage2,#uploadImage3',
		url: '/upload/',
		done: function(res, index, upload) {
			if(res.code == 0) { //上传成功
				var tr = demoListView.find('tr#upload-' + index),
					tds = tr.children();
				tds.eq(2).html('<span style="color: #5FB878;">上传成功</span>');
				tds.eq(3).html(''); //清空操作
				return delete this.files[index]; //删除文件队列已经上传成功的文件
			}
			this.error(index, upload);
		},
	});

});