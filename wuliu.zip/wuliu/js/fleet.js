layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	form = layui.form;
	//监听工具条
	table.on('tool(demo)', function(obj) {
		var data = obj.data;
		if(obj.event === 'detail') {
			editpop("transportFleetDetail.html?"+data.id);
		} else if(obj.event === 'edit') {
			editpop("transportFleetEdit.html?"+data.id);
		}
	});
	table.render({
		elem: '#fleettable',
		height: '471',
		limit: 10,
		page: true,
		cols: [
			[{
				checkbox: true,
				fixed: true
			}, {
				type: 'numbers'
			}, {
				field: 'id',
				title: '车队编号',
				width: 210

			}, {
				field: 'cName',
				title: '所属企业',
				width: 210

			}, {
				field: 'tName',
				title: '车队名称',
				width: 210

			}, {
				title: '具体操作',
				toolbar: '#fleetbar',
				width: 160
			}]
		],
		id: 'testReload',

		data: [{
			"id": "10001",
			"cName": "天津*******",
			"tName": "一条龙车队",
		}, {
			"id": "10001",
			"cName": "天津*******",
			"tName": "一条龙车队",
		}, {
			"id": "10001",
			"cName": "天津*******",
			"tName": "一条龙车队",
		}, {
			"id": "10001",
			"cName": "天津*******",
			"tName": "一条龙车队",
		}]
	});
	var $ = layui.$,
		active = {
			reload: function() {
				var demoReload = $('#demoReload');

				//执行重载
				table.reload('testReload', {
					page: {
						curr: 1 //重新从第 1 页开始
					},
					where: {
						key: {
							id: demoReload.val()
						}
					}
				});
			}
		};

	$('.demoTable .layui-btn').on('click', function() {
		var type = $(this).data('type');
		active[type] ? active[type].call(this) : '';
	});
	form.on('checkbox(lockDemo)', function(obj) {
		layer.tips(this.value + ' ' + this.name + '：' + obj.elem.checked, obj.othis);
	});
});