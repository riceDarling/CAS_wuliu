layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	//引入layui
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	//引入map
	$(function() {
		try {
			var map = new AMap.Map('mapcontainer', {
				resizeEnable: true,
				zoom: 16,
				center: [117.20, 39.13]
			});
			//引入map控制条
			AMap.plugin(['AMap.ToolBar', 'AMap.Scale', 'AMap.OverView'], function() {
				map.addControl(new AMap.ToolBar());
				map.addControl(new AMap.Scale());
				map.addControl(new AMap.OverView({
					isOpen: true
				}));
			})
		} catch(e) {
			console.log(e);
		}
		//引入引入左边栏树状图
		var form = layui.form;
		var data = [{
			title: "全部",
			value: "all",
			data: [{
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}]
		}]
		//测试用，以循环形式产生树状图内容
		for(var one in data[0].data) {
			for(var i = 0; i < 50; i++) {
				data[0].data[one].data.push({
					title: "节点aabbccddabadfasdfaefsadfas",
					checked: true,
					disabled: false,
					value: "jd1.1",
					data: []
				})
			}
		}

		//生成树状图
		var sidertree = new layuiXtree({
			elem: 'xtree2',
			form: form,
			color: {
				open: "#EE9A00",
				close: "#EEC591",
				end: "#c8c8c8"
			},
			data: data,
			click: function(data) {

			}
		})
	})
})