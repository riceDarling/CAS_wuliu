layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	form = layui.form;

	//监听工具条
	table.on('tool(demo)', function(obj) {
		var data = obj.data;
		if(obj.event === 'detail') {
			editpop("transportDriverDetail.html?"+data.id);
		}else if(obj.event === 'edit') {
			editpop("transportDriverEdit.html?"+data.id);
		}
	});
	table.render({
		elem: '#drivertable',
		height: '471',
		limit: 10,
		page: true,
		cols: [
			[{
				checkbox: true,
				fixed: true
			}, {
				type: 'numbers'
			}, {
				field: 'id',
				title: '驾驶员编号',
				width: 100

			}, {
				field: 'Name',
				title: '姓名',
				width: 100
			}, {
				field: 'tel',
				title: '联系电话',
				width: 120
			}, {
				field: 'cName',
				title: '驾驶员所属企业',
				width: 150
			}, {
				field: 'cNum',
				title: '驾驶车辆牌照',
				width: 120
			}, {
				field: 'carStyle',
				title: '准驾车型',
				width: 120
			},  {
				field: 'effective',
				title: '是否冻结',
				width: 110,
				templet: '#drivercheckboxTpl',
				unresize: false

			}, {
				title: '具体操作',
				toolbar: '#driverbar',
				width: 150
			}]
		],
		id: 'testReload',
		data: [{
			"id": "10001",
			"Name": "点点滴滴",
			"tel": "13786534567",
			"cName": "天津统统",
			"cNum": "11111111111111111",
			"carStyle": "111",
		}, {
			"id": "10001",
			"Name": "点点滴滴",
			"tel": "13786534567",
			"cName": "天津统统",
			"cNum": "11111111111111111",
			"carStyle": "111",
		}, {
			"id": "10001",
			"Name": "点点滴滴",
			"tel": "13786534567",
			"cName": "天津统统",
			"cNum": "11111111111111111",
			"carStyle": "111",
		}, {
			"id": "10001",
			"Name": "点点滴滴",
			"tel": "13786534567",
			"cName": "天津统统",
			"cNum": "11111111111111111",
			"carStyle": "111",
		}]
	});
	var $ = layui.$,
		active = {
			reload: function() {
				var demoReload = $('#demoReload');

				//执行重载
				table.reload('testReload', {
					page: {
						curr: 1 //重新从第 1 页开始
					},
					where: {
						key: {
							id: demoReload.val()
						}
					}
				});
			}
		};

	$('.demoTable .layui-btn').on('click', function() {
		var type = $(this).data('type');
		active[type] ? active[type].call(this) : '';
	});

	form.on('checkbox(lockDemo)', function(obj) {
		layer.tips(this.value + ' ' + this.name + '：' + obj.elem.checked, obj.othis);
	});
});
layui.use('upload', function() {
	var $ = layui.jquery,
		upload = layui.upload;

	//拖拽上传
	upload.render({
		elem: '#uploadImage1,#uploadImage2,#uploadImage3,#uploadImage4,#uploadImage5,#uploadImage6',
		url: '/upload/',
		done: function(res, index, upload) {
			if(res.code == 0) { //上传成功
				var tr = demoListView.find('tr#upload-' + index),
					tds = tr.children();
				tds.eq(2).html('<span style="color: #5FB878;">上传成功</span>');
				tds.eq(3).html(''); //清空操作
				return delete this.files[index]; //删除文件队列已经上传成功的文件
			}
			this.error(index, upload);
		},
	});

});