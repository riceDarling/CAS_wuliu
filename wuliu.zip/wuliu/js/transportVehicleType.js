layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	form = layui.form;
	//监听工具条
	table.on('tool(demo)', function(obj) {
		var data = obj.data;
		
		if(obj.event === 'detail') {
			editpop("transportVerhicleTypeDetail.html?"+data.id);
		} else if(obj.event === 'del') {
			layer.confirm('真的删除行么', function(index) {
				obj.del();
				layer.close(index);
			});
		} else if(obj.event === 'edit') {
			editpop("transportVerhicleTypeEdit.html?"+data.id);
		}
	});

	table.render({
		elem: '#vehicleTypeTable',
		height: '471',
		limit: 10,
		page: true,
		id: 'testReload',
		cols: [
			[ //表头
				{type:'numbers'},
				{
					field: 'desc',
					title: '车辆类型',
					width: 150,
					sort: true
				},{
					field: 'bulk',
					title: '容积（立方米）',
					width: 150,
					sort: true
				},{
					field: 'lwh',
					title: '长*宽*高（米）',
					width: 150,
					sort: true
				},{
					field: 'capacity',
					title: '载重（吨）',
					width: 130,
					sort: true
				},{
					field: 'operation',
					title: '具体操作',
					//width: 170,
					sort: true,
					toolbar: '#vehicleTypebar',

				}
			]
		],
		data: [{
			desc: "123",
			bulk: "4.5",
			lwh: "2.7*1.4*1.9",
			capacity: "1",
			
		},{
			desc: "123",
			bulk: "4.5",
			lwh: "2.7*1.4*1.9",
			capacity: "1",
		
		},{
			desc: "123",
			bulk: "4.5",
			lwh: "2.7*1.4*1.9",
			capacity: "1",
		
		},{
			desc: "123",
			bulk: "4.5",
			lwh: "2.7*1.4*1.9",
			capacity: "1",
			
		},{
			desc: "123",
			bulk: "4.5",
			lwh: "2.7*1.4*1.9",
			capacity: "1",
			
		},{
			desc: "123",
			bulk: "4.5",
			lwh: "2.7*1.4*1.9",
			capacity: "1",
			
		},
		]
		
	});
	
	var $ = layui.$, active = {
    reload: function(){
      var demoReload = $('#demoReload');
      
      //执行重载
      table.reload('testReload', {
        page: {
          curr: 1 //重新从第 1 页开始
        }
        ,where: {
          key: {
            id: demoReload.val()
          }
        }
      });
    }
  };
  
  $('.demoTable .layui-btn').on('click', function(){
    var type = $(this).data('type');
    active[type] ? active[type].call(this) : '';
    
  });
  
	
});