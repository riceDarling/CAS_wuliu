layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	form = layui.form;
	//监听工具条
	table.on('tool(demo)', function(obj) {
		var data = obj.data;
		
		if(obj.event === 'detail') {
			editpop("announcementHistoryDetail.html?"+data.id);
		} else if(obj.event === 'del') {
			layer.confirm('真的删除行么', function(index) {
				obj.del();
				layer.close(index);
			});
		} else if(obj.event === 'edit') {
			layer.alert('编辑行：<br>' + JSON.stringify(data))
		}
	});

	table.render({
		elem: '#historyTable',
		height: '471',
		limit: 10,
		page: true,
		id: 'testReload',
		cols: [
			[ //表头
				{checkbox: true, fixed: true}
				,{type:'numbers'}
				,{
					field: 'title',
					title: '发布标题',
					//width: 100
					
				}, {
					field: 'content',
					title: '发布内容',
					//width: 100,
					sort: true,
				}, {
					field: 'issueTime',
					title: '发布时间',
					//width: 100,
					sort: true
				}, {
					field: 'count',
					title: '接收人数',
					//width: 100,
					sort: true
				},{
					field: 'senderAdminName',
					title: '发送人',
					//width: 100,
					sort: true
				},{
					field: 'isRead',
					title: '是否已读',
					//width: 100,
					sort: true
				},{
					field: 'operation',
					title: '具体操作',
					width: 120,
					toolbar: '#historybar',

				},
			]
		],
		data: [{
			title: "123",
			content: "123",
			issueTime: "12344333",
			count: "1",
			senderAdminName:"qq",
			isRead:"已读",
		},{
			title: "123",
			content: "123",
			issueTime: "12344333",
			count: "1",
			senderAdminName:"qq",
			isRead:"已读",

		},{
			title: "123",
			content: "123",
			issueTime: "12344333",
			count: "1",
			senderAdminName:"qq",
			isRead:"已读",
		},{
			title: "123",
			content: "123",
			issueTime: "12344333",
			count: "1",
			senderAdminName:"qq",
			isRead:"已读",
		},]
		
	});
	
	var $ = layui.$, active = {
    reload: function(){
      var demoReload = $('#demoReload');
      
      //执行重载
      table.reload('testReload', {
        page: {
          curr: 1 //重新从第 1 页开始
        }
        ,where: {
          key: {
            id: demoReload.val()
          }
        }
      });
    }
  };
  
  $('.demoTable .layui-btn').on('click', function(){
    var type = $(this).data('type');
    active[type] ? active[type].call(this) : '';
    
  });
  
	//监听锁定操作
	form.on('checkbox(lockDemo)', function(obj) {
		layer.tips(this.value + ' ' + this.name + '：' + obj.elem.checked, obj.othis);
	});
});