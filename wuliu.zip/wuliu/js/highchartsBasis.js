function chart(elem) {
	layui.use("jquery", function() {
		var element = layui.element,
			$ = layui.$;
		var that = this;
		//多窗口模式，层叠置顶
		layer.open({
			type: 2 //此处以iframe举例
				,
			title: $(elem).text(),
			area: ['700px', '500px'],
			shade: 0.3,
			maxmin: false,
			content: ['' + $(elem).attr("popup") + '.html'],
			zIndex: layer.zIndex //重点1
				,
			success: function(layero) {
				console.log()
				layer.setTop(layero); //重点2
			}
		});

	})
}
