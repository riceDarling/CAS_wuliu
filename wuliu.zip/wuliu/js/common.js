function popthis(elem) {
	layui.use("jquery", function() {
		var element = layui.element,
			$ = layui.$;
		if($(elem).attr("popup") != undefined && $(elem).attr("popup") != null && $(elem).attr("popup") != "") {
			if($(elem).is("[fullwindow]")) {
				var pop = layer.open({
					type: 2,
					title: $(elem).text(),
					maxmin: false,
					shade: 0.3,
					move: false,
					area: ['1024px', '600px'],
					anim: 232312,
					content: ['' + $(elem).attr("popup") + '.html'], //iframe的url，no代表不显示滚动条
					success: function(layero, index) {
						layer.full(pop);
						$(window).resize(function(){
						layer.full(pop);
						})
					}
				});
			} else {
				var pop = layer.open({
					type: 2,
					title: $(elem).text(),
					maxmin: false,
					shade: 0.3,
					move: false,
					area: ['893px', '600px'],
					anim: 232312,
					content: ['' + $(elem).attr("popup") + '.html'], //iframe的url，no代表不显示滚动条
				});
			}

		}

	})

}

function pop(elem) {
	layui.use("jquery", function() {
		var element = layui.element,
			$ = layui.$;
		var that = this;
		//多窗口模式，层叠置顶
		layer.open({
			type: 2 //此处以iframe举例
				,
			title: $(elem).text(),
			area: ['700px', '500px'],
			shade: 0.3,
			maxmin: false,
			move: false,
			content: ['' + $(elem).attr("popup") + '.html'],
			zIndex: layer.zIndex //重点1
				,
			success: function(layero) {
				console.log()
				layer.setTop(layero); //重点2
			}
		});

	})
}
function editpop(html) {
	layui.use("jquery", function() {
			layer.open({
				type: 2 ,//此处以iframe举例,
				title: "编辑",
				area: ['700px', '500px'],
				shade: 0.3,
				maxmin: false,
				content:html,
				zIndex: layer.zIndex ,//重点1
				success: function(layero) {
				}
			});
	});
}
function vehiclepop(vehicleId){
	layui.use("jquery", function() {
		var element = layui.element,
			$ = layui.$;
			layer.open({
				type: 2,
				title:'车辆信息' ,
				maxmin: false,
				shade: 0.3,
				move:false,
				area: ['893px', '600px'],
				anim: 232312,
				content:'vehicleInfo.html?'+vehicleId,
				end: function() { //此处用于演示
				}
			});
	})
}
function qrcodepop(elem) {
		layui.use("jquery", function() {
			var element = layui.element,
				$ = layui.$;
			var that = this;
			//多窗口模式，层叠置顶
			layer.open({
				type: 2 //此处以iframe举例
					,
				title: $(elem).text(),
				area: ['240px', '270px'],
				shade: 0.3,
				maxmin: false,
				move:false,
				content: ['' + $(elem).attr("popup") + '.html'],
				zIndex: layer.zIndex //重点1
					,
				success: function(layero) {
					console.log()
					layer.setTop(layero); //重点2
				}
			});

		})
}
