layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	form = layui.form;
	//监听工具条
	table.on('tool(demo)', function(obj) {
		var data = obj.data;
		if(obj.event === 'detail') {
			layer.msg('ID：' + data.id + ' 的查看操作');
		} 
	});
	table.render({
		elem: '#platformAlarmTable',
		height: '471',
		limit: 10,
		page: true,
		id: 'testReload',
		cols: [
			[ //表头
				{type:'numbers'},
				{
					field: 'num',
					title: '车牌号',
					width: 100,
					sort: true,
				}, {
					field: 'driverName',
					title: '驾驶员',
					width: 80,
					sort: true,
				}, {
					field: 'color',
					title: '车辆颜色',
					width: 100,
					sort: true
				}, {
					field: 'longitude',
					title: '经度',
					width: 100,
					sort: true
				}, {
					field: 'latitude',
					title: '纬度',
					width: 100,
					sort: true
				}, {
					field: 'location',
					title: '位置信息',
					width: 100,
					sort: true
				}, {
					field: 'velocity',
					title: '速度',
					width: 70,
					sort: true
				}, {
					field: 'type',
					title: '报警类型',
					width: 100,
					sort: true
				}, {
					field: 'solution',
					title: '报警解除方式',
					width: 130,
					sort: true
				}, {
					field: 'adminId',
					title: '操作员',
					width: 90,
					sort: true
				}, {
					field: 'dealWay',
					title: '处理方式',
					width: 100,
					sort: true
				}, {
					field: 'dealTime',
					title: '处理时间',
					width: 120,
					sort: true
				}, 
			]
		],
		data: [{
			num: "津ABC23",
			driverName:"李",
			color:"蓝",
			longitude: "117",
			latitude:"39",
			location:"39",
			velocity:"39",
			type:"39",
			solution:"39",
			adminId:"39",
			dealWay:"39",
			dealTime:"39",
			
		}, {
			num: "津ABC23",
			driverName:"李",
			color: "蓝",
			longitude: "117",
			latitude:"39",
			location:"39",
			velocity:"39",
			type:"39",
			solution:"39",
			adminId:"39",
			dealWay:"39",
			dealTime:"39",
			
		}, {
			num: "津ABC23",
			driverName:"李",
			color: "蓝",
			longitude: "117",
			latitude:"39",
			location:"39",
			velocity:"39",
			type:"39",
			solution:"39",
			adminId:"39",
			dealWay:"39",
			dealTime:"39",
			
		}, {
			num: "津ABC23",
			driverName:"李",
			color: "蓝",
			longitude: "117",
			latitude:"39",
			location:"39",
			velocity:"39",
			type:"39",
			solution:"39",
			adminId:"39",
			dealWay:"39",
			dealTime:"39",
			
		}, 
		]
	});
	
	var $ = layui.$, active = {
    reload: function(){
      var demoReload = $('#demoReload');
      
      //执行重载
      table.reload('testReload', {
        page: {
          curr: 1 //重新从第 1 页开始
        }
        ,where: {
          key: {
            id: demoReload.val()
          }
        }
      });
    }
  };
  
  $('.demoTable .layui-btn').on('click', function(){
    var type = $(this).data('type');
    active[type] ? active[type].call(this) : '';
    
  });
	
	
	
	
	$(function() {
		//引入引入左边栏树状图
		var form = layui.form;
		var data = [{
			title: "全部",
			value: "all",
			data: [{
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}]
		}]
		//测试用，以循环形式产生树状图内容
		for(var one in data[0].data) {
			for(var i = 0; i < 20; i++) {
				data[0].data[one].data.push({
					title: "节点111",
					checked: true,
					disabled: false,
					value: "jd1.1",
					data: []
				})
			}
		}
		//生成树状图
		var sidertree = new layuiXtree({
			elem: 'platformAlarm-xtree',
			form: form,
			color: {
				open: "#EE9A00",
				close: "#EEC591",
				end: "#c8c8c8"
			},
			data: data,
			
			click: function(data) {
			}
		})
	})
});

layui.use(['form', 'layedit', 'laydate'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
  
  //日期
  laydate.render({
    elem: '#platformAlarmEnddate'
  });
  laydate.render({
    elem: '#platformAlarmStartdate'
  });
  
  });