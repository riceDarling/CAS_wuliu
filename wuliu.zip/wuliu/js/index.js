layui.use(['jquery', 'element', 'form', 'table', 'layer'], function() {
	//引入layui
	var element = layui.element,
		$ = layui.$,
		layer = layui.layer,
		table = layui.table;
	//引入map
	$(function() {
		//引入引入左边栏树状图
		var form = layui.form;
		var data = [{
			title: "全部",
			value: "all",
			data: [{
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}, {
				title: "节点1",
				value: "jd1",
				data: []
			}]
		}]
		//测试用，以循环形式产生树状图内容
		for(var one in data[0].data) {
			for(var i = 0; i < 50; i++) {
				data[0].data[one].data.push({
					title: "节点aabbccddabadfasdfaefsadfas",
					checked: true,
					disabled: false,
					value: "jd1.1",
					data: []
				})
			}
		}

		//生成树状图
		var sidertree = new layuiXtree({
			elem: 'xtree1',
			form: form,
			color: {
				open: "#EE9A00",
				close: "#EEC591",
				end: "#c8c8c8"
			},
			data: data,
			click: function(data) {

			}
		})
		//初始化底部高度
		var defaultbottom = -$(".layui-footer").height();
		$(".layui-footer").css({
			"bottom": defaultbottom,
			"visibility": "visible"
		});
		//第一个实例
		table.render({
			elem: '#footer-table1',
			height: 250,
			page: true,
			cellMinWidth:100,
			cols: [
				[ //表头
					{
						field: 'lpNum',
						title: '车牌号',

						sort: true,
					}, {
						field: 'equipmentNum',
						title: '车载设备ID',
						minWidth:120,
						sort: true,
					}, {
						field: 'type',
						title: '车辆类型',
						sort: true
					}, {
						field: 'color',
						title: '车牌颜色',
						sort: true,
					}, {
						field: 'driver',
						title: '驾驶员',
						sort: true,
					}, {
						field: 'speed',
						title: '速度与方向',
						minWidth:120,
						sort: true
					}, {
						field: 'location',
						title: '位置信息',
						minWidth:140,
						sort: true
					}, {
						field: 'time',
						title: '发送时间',
						minWidth:170,
						sort: true,
					}, {
						field: 'state',
						title: '状态',
						minWidth:180,
						sort: true
					}, {
						field: 'police',
						title: '报警信息',
						//						width: 80，
						sort: true,
					}, {
						field: 'vendor',
						title: '厂商ID',
						//						width: 135,
						sort: true
					}
				]
			],
			data: [{
				lpNum: "津ABT123",
				equipmentNum: "12344333",
				type: "危险品",
				color: "红",
				driver: "张三",
				speed: "100km/h,正北",
				location: "天津市西青区",
				time: "2018-01-19 18:32:45",
				state: "ACC关-未定位-北纬",
				police: "超速",
				vendor: "1111"

			}, {
				lpNum: "津ABT123",
				equipmentNum: "12344333",
				type: "危险品",
				color: "红",
				driver: "张三",
				speed: "100km/h,正北",
				location: "天津市西青区",
				time: "2018-01-19 18:32:45",
				state: "ACC关-未定位-北纬",
				police: "超速",
				vendor: "1111"
			}, {
				lpNum: "津ABT123",
				equipmentNum: "12344333",
				type: "危险品",
				color: "红",
				driver: "张三",
				speed: "100km/h,正北",
				location: "天津市西青区",
				time: "2018-01-19 18:32:45",
				state: "ACC关-未定位-北纬",
				police: "超速",
				vendor: "1111"
			}, ]
		});
		table.render({
			elem: '#footer-table2',
			height: 250,
			page: true,
			cellMinWidth:100,
			cols: [
				[ //表头
					{
						field: 'lpNum',
						title: '车牌号11',
						sort: true,
					}, {
						field: 'equipmentNum',
						title: '车载设备ID',
						minWidth:120,
						sort: true,
					}, {
						field: 'type',
						title: '车辆类型',
						sort: true
					}, {
						field: 'color',
						title: '车牌颜色',
						sort: true,
					}, {
						field: 'driver',
						title: '驾驶员',
						sort: true,
					}, {
						field: 'speed',
						title: '速度与方向',
						minWidth:120,
						sort: true
					}, {
						field: 'location',
						title: '位置信息',
						minWidth:140,
						sort: true
					}, {
						field: 'time',
						title: '发送时间',
						minWidth:170,
						sort: true,
					}, {
						field: 'state',
						title: '状态',
						minWidth:180,
						sort: true
					}, {
						field: 'police',
						title: '报警信息',
						sort: true,
					}, {
						field: 'vendor',
						title: '厂商ID',
						sort: true
					}
				]
			],
			data: [{
				lpNum: "津ABT123",
				equipmentNum: "12344333",
				type: "危险品",
				color: "红",
				driver: "张三",
				speed: "100km/h,正北",
				location: "天津市西青区",
				time: "2018-01-19 18:32:45",
				state: "ACC关-未定位-北纬",
				police: "超速",
				vendor: "1111"

			},{
				lpNum: "津ABT123",
				equipmentNum: "12344333",
				type: "危险品",
				color: "红",
				driver: "张三",
				speed: "100km/h,正北",
				location: "天津市西青区",
				time: "2018-01-19 18:32:45",
				state: "ACC关-未定位-北纬",
				police: "超速",
				vendor: "1111"
			}, ],
		});
		//重置table滚动条
		$(document).on("click",".layui-footer .layui-tab-title li",function(){
			setTimeout(function(){
				$(window).resize();
			},100)
		})
		//ui缩放-左
		$(document).on("click", "#leftsider_xk .layui-layout-right", function() {
			if($(this).attr("sidertype") == "0") {
				//收缩-展开
				$(this).attr("sidertype", "1");
				$(".layui-body").animate({
					"left": "200px"
				}, 250);
				$("#leftsider_xk").removeClass("transparentsider").animate({
					"left": "0"
				}, 250);
				$(".layui-footer").animate({
					"left": "200px"
				}, 250);
				$(this).children(".layui-icon").html("&#xe603;");

			} else if($(this).attr("sidertype") == "1") {
				//展开-收缩
				$(this).attr("sidertype", "0");
				$(".layui-body").animate({
					"left": "0"
				}, 250);
				$("#leftsider_xk").addClass("transparentsider").animate({
					"left": "-184px"
				}, 250);
				$(".layui-footer").animate({
					"left": "16px"
				}, 250);
				$(this).children(".layui-icon").html("&#xe602;");
			};
		})
		//ui缩放-底
		$(document).on("click", "#footer-ctrl", function() {
			if($(this).attr("footertype") == "0") {
				//收缩-展开
				$(this).attr("footertype", "1").html("&#xe61a;");
				$(".layui-footer").animate({
					"bottom": "0"
				}, 250);
			} else if($(this).attr("footertype") == "1") {
				//展开-收缩
				$(this).attr("footertype", "0").html("&#xe619;");
				var defaultbottom = -$(".layui-footer").height();
				$(".layui-footer").animate({
					"bottom": defaultbottom
				}, 250);
			}
		});

	})
	$(document).on('click','.layui-nav-item a.positionSearch',function(){
		$('#myPageTop').show();
	})

})

